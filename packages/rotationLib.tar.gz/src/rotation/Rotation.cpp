//////////////////////////////////////////////////////////////////////////////////////////////////
/*! \file Rotation.cpp
*  \brief Implementation of Rotation Namespace Objects.
*  \brief Provides a set of functions to use Rotation matrices
*         and their various representations.
*  \author Andrew Turner <ajturner@vt.edu>
*  \author Chris Hall <cdhall@vt.edu>
*  \version 0.1
*  \date    2001-2003
//////////////////////////////////////////////////////////////////////////////////////////////////
*  \bug Matrix class doesn't currently work
*  \warning 
*  \todo Implement Gibbs vector representation
*/
//////////////////////////////////////////////////////////////////////////////////////////////////

#include "Rotation.h"

Rotation::Rotation() { }

Rotation::~Rotation() { }

Rotation::Rotation(const Matrix &_inMatrix) { Set(_inMatrix); }

Rotation::Rotation(const DirectionCosineMatrix &_Matrix) { Set(_Matrix); }

Rotation::Rotation(const Vector &_Angles, const int &_Sequence) { Set(_Angles, _Sequence); }

Rotation::Rotation(const double &_Angle1, const double &_Angle2, const double &_Angle3, const int &_Sequence) { Set(_Angle1, _Angle2, _Angle3, _Sequence); }

Rotation::Rotation(const Vector &_Axis, const double &_Angle) { Set(_Axis, _Angle); }

Rotation::Rotation(const ModifiedRodriguezParameters &_MRP) { Set(_MRP); }

Rotation::Rotation(const Quaternion &_quat) { Set(_quat); }

void Rotation::Set(const Matrix &_inMatrix)
{
    if((_inMatrix[MatrixRowsIndex].getIndexCount() == 3) && (_inMatrix[MatrixColsIndex].getIndexCount() == 3))
    {
        m_quaternion.Set(_inMatrix);
    }
    return;
}

void Rotation::Set(const DirectionCosineMatrix &_DCM)
{
    m_quaternion.Set(_DCM);
    return;
}

void Rotation::Set(const Vector &_Angles, const int &_Sequence)
{
    m_quaternion.Set(_Angles, _Sequence);
    return;
}

void Rotation::Set(const double &_Angle1, const double &_Angle2, const double &_Angle3, const int &_Sequence)
{
    m_quaternion.Set(_Angle1, _Angle2, _Angle3, _Sequence);
    return;
}

void Rotation::Set(const Vector &_Axis, const double &_Angle)
{
    m_quaternion.Set(_Axis, _Angle);
    return;
}

void Rotation::Set(const ModifiedRodriguezParameters &_MRP)
{
    m_quaternion.Set(_MRP);
    return;
}

void Rotation::Set(const Quaternion &_quat)
{
    m_quaternion = _quat;
    return;
}

// Inspectors
DirectionCosineMatrix Rotation::GetDCM() const
{
    return DirectionCosineMatrix(m_quaternion);
}

Vector Rotation::GetEulerAngles(const int& _Sequence)
{
    return m_quaternion.GetEulerAngles(_Sequence);
}

void Rotation::GetEulerAxisAngle(Vector &_EulerAxis, double &_EulerAngle) const
{
    m_quaternion.GetEulerAxisAngle(_EulerAxis, _EulerAngle);
    return;
}

ModifiedRodriguezParameters Rotation::GetMRP() const
{
    return ModifiedRodriguezParameters(m_quaternion);
}

Quaternion Rotation::GetQuaternion() const
{
    return m_quaternion;
}


Rotation Rotation::operator* (const Rotation& _rot2) const
{
    Rotation rotOut((*this).GetDCM() * _rot2.GetDCM());
    return rotOut;
}
Rotation Rotation::operator~ () const
{
    Rotation rotOut(~((*this).GetDCM()));
    return rotOut;
}

//////////////////////////////////////////////////////////////////////////
// DirectionCosineMatrix Class
DirectionCosineMatrix::DirectionCosineMatrix():Matrix(DCM_SIZE, DCM_SIZE)
{
    (*this) = eye(DCM_SIZE);
}
DirectionCosineMatrix::DirectionCosineMatrix(const DirectionCosineMatrix &_DCM):Matrix(DCM_SIZE, DCM_SIZE)
{
    Set(_DCM);
}
DirectionCosineMatrix::DirectionCosineMatrix(const Matrix &_DCM):Matrix(DCM_SIZE, DCM_SIZE)
{
    Set(_DCM);
}

DirectionCosineMatrix::DirectionCosineMatrix(const Vector &_EulerAngles, const int &_Sequence):Matrix(DCM_SIZE, DCM_SIZE)
{	
    Set(_EulerAngles, _Sequence);
}

DirectionCosineMatrix::DirectionCosineMatrix(const double &_Angle1, const double &_Angle2, const double &_Angle3, const int &_Sequence):Matrix(DCM_SIZE, DCM_SIZE)
{	
    Set(_Angle1, _Angle2, _Angle3, _Sequence);
}

DirectionCosineMatrix::DirectionCosineMatrix(const Vector &_EulerAxis, const double &_EulerAngle):Matrix(DCM_SIZE, DCM_SIZE)
{	
    Set(_EulerAxis, _EulerAngle);
}

DirectionCosineMatrix::DirectionCosineMatrix(const ModifiedRodriguezParameters &_MRP):Matrix(DCM_SIZE, DCM_SIZE)
{	
    Set(_MRP);
}
DirectionCosineMatrix::DirectionCosineMatrix(const Quaternion &_quat):Matrix(DCM_SIZE, DCM_SIZE)
{	
    Set(_quat);
}

void DirectionCosineMatrix::Set(const DirectionCosineMatrix &_DCM)
{
    (*this) = _DCM;
    return;
}

void DirectionCosineMatrix::Set(const Vector &_EulerAngles, const int &_Sequence)
{
    Set(_EulerAngles(VectorIndexBase+0), _EulerAngles(VectorIndexBase+1), _EulerAngles(VectorIndexBase+2), _Sequence);
    return;
}

void DirectionCosineMatrix::Set(const double &_Angle1, const double &_Angle2, const double &_Angle3, const int &_Sequence)
{
    switch(_Sequence)
    {
        case 121: (*this) = R1(_Angle3) * R2(_Angle2) * R1(_Angle1); break;
        case 131: (*this) = R1(_Angle3) * R3(_Angle2) * R1(_Angle1); break;
        case 132: (*this) = R2(_Angle3) * R3(_Angle2) * R1(_Angle1); break;
        case 123: (*this) = R3(_Angle3) * R2(_Angle2) * R1(_Angle1); break;
        case 212: (*this) = R2(_Angle3) * R1(_Angle2) * R2(_Angle1); break;
        case 321: (*this) = R1(_Angle3) * R2(_Angle2) * R3(_Angle1); break;
        case 232: (*this) = R2(_Angle3) * R3(_Angle2) * R2(_Angle1); break;
        case 231: (*this) = R1(_Angle3) * R3(_Angle2) * R2(_Angle1); break;
        case 213: (*this) = R3(_Angle3) * R1(_Angle2) * R2(_Angle1); break;
        case 313: (*this) = R3(_Angle3) * R1(_Angle2) * R3(_Angle1); break;
        case 323: (*this) = R3(_Angle3) * R2(_Angle2) * R3(_Angle1); break;
        case 312: (*this) = R2(_Angle3) * R1(_Angle2) * R3(_Angle1); break;
        default: (*this) = eye(DCM_SIZE);
    }
    return;
}

/*! \fn void DirectionCosineMatrix::Set(const Vector &_EulerAxis, const double &_EulerAngle)
* Equation: (Ref Wertz, pg. 413)
\f[
    \left[\bf{R}]
    =
    \begin{bmatrix}
    e^{2}_1 \Phi + \cos{\phi} & e_1 e_2 \Phi + e_3\sin{\phi} & e_1 e_3 \Phi - e_2\sin{\phi}\\
    e_2 e_1 \Phi - e_3\sin{\phi} & e^{2}_2 \Phi + \cos{\phi} & e_2 e_3 \Phi + e_1\sin{\phi}\\
    e_3 e_1 \Phi + e_2\sin{\phi} & e_3 e_2 \Phi - e_1\sin{\phi} & e^{2}_3 \Phi + \cos{\phi}
    \end{bmatrix}\\
    where \Phi= 1 - \cos{\phi} (Ref Hughes p.12)
    \f]
*/
void DirectionCosineMatrix::Set(const Vector &_EulerAxis, const double &_EulerAngle)
{
    // Calculations done for each element to increase speed
    double Phi = 1 - cos(_EulerAngle);
    double e1 = _EulerAxis(VectorIndexBase+0);
    double e2 = _EulerAxis(VectorIndexBase+1);
    double e3 = _EulerAxis(VectorIndexBase+2);
    double cosPhi = cos(_EulerAngle);
    double sinPhi = sin(_EulerAngle);
    
    // Column 1
    (*this)(MatrixIndexBase+0,MatrixIndexBase+0) = e1 * e1 * Phi + cosPhi;
    (*this)(MatrixIndexBase+0,MatrixIndexBase+1) = e2 * e1 * Phi - e3 * sinPhi;
    (*this)(MatrixIndexBase+0,MatrixIndexBase+2) = e3 * e1 * Phi + e2 * sinPhi;
        
    // Column 2
    (*this)(MatrixIndexBase+1,MatrixIndexBase+0) = e1 * e2 * Phi + e3 * sinPhi;
    (*this)(MatrixIndexBase+1,MatrixIndexBase+1) = e2 * e2 * Phi + cosPhi; 
    (*this)(MatrixIndexBase+1,MatrixIndexBase+2) = e3 * e2 * Phi - e1 * sinPhi;
    
    // Column 3
    (*this)(MatrixIndexBase+2,MatrixIndexBase+0) = e1 * e3 * Phi - e2 * sinPhi;
    (*this)(MatrixIndexBase+2,MatrixIndexBase+1) = e2 * e3 * Phi + e1 * sinPhi;
    (*this)(MatrixIndexBase+2,MatrixIndexBase+2) = e3 * e3 * Phi + cosPhi;
    return;
}

/*! \fn void DirectionCosineMatrix::Set(const ModifiedRodriguezParameters &_MRP)
* Equation: 
\f[
    \left[\bf{R}\left(\bf{\sigma}\right)\right]
    =
    \frac{1}{\left(1+\sigma^2\right)^2}
    \begin{bmatrix}
    4\left(\sigma^{2}_1-\sigma^{2}_2-\sigma^{2}_3\right)+\Sigma^2 & 8\sigma_1\sigma_2+4\sigma_3\Sigma & 8\sigma_1\sigma_3-4\sigma_2\Sigma\\
    8\sigma_2\sigma_1-4\sigma_3\Sigma & 4\left(-\sigma^{2}_1+\sigma^{2}_2-\sigma^{2}_3\right)+\Sigma^2 & 8\sigma_2\sigma_3+4\sigma_1\Sigma
    8\sigma_3\sigma_1+4\sigma_2\Sigma & 8\sigma_3\sigma_2-4\sigma_1\Sigma & 4\left(-\sigma^{2}_1-\sigma^{2}_2+\sigma^{2}_3\right)+\Sigma^2
    \end{bmatrix}\\
    where \Sigma=1-\bf{\sigma}^T\bf{\sigma}
    \f]
*/
void DirectionCosineMatrix::Set(const ModifiedRodriguezParameters &_MRP)
{
    // Calculations done for each element to increase speed
    Matrix tempMatrix = ((~_MRP) * _MRP);
    double Sigma = 1 - tempMatrix(MatrixIndexBase,MatrixIndexBase);
    double sigma1 = _MRP(VectorIndexBase+0);
    double sigma2 = _MRP(VectorIndexBase+1);
    double sigma3 = _MRP(VectorIndexBase+2);
    
    // Column 1
    (*this)(MatrixIndexBase+0,MatrixIndexBase+0) = 4*(sigma1*sigma1 - sigma2*sigma2 - sigma3*sigma3) + Sigma*Sigma;
    (*this)(MatrixIndexBase+0,MatrixIndexBase+1) = 8*sigma2*sigma1 - 4*sigma3*Sigma;
    (*this)(MatrixIndexBase+0,MatrixIndexBase+2) = 8*sigma3*sigma1 + 4*sigma2*Sigma;
    
    // Column 2
    (*this)(MatrixIndexBase+1,MatrixIndexBase+0) = 8*sigma1*sigma2 + 4*sigma3*Sigma;
    (*this)(MatrixIndexBase+1,MatrixIndexBase+1) = 4*(-sigma1*sigma1 + sigma2*sigma2 - sigma3*sigma3) + Sigma*Sigma;
    (*this)(MatrixIndexBase+1,MatrixIndexBase+2) = 8*sigma3*sigma2 - 4*sigma1*Sigma;
    
    // Column 3
    (*this)(MatrixIndexBase+2,MatrixIndexBase+0) = 8*sigma1*sigma3 - 4*sigma2 * Sigma;
    (*this)(MatrixIndexBase+2,MatrixIndexBase+1) = 8*sigma2*sigma3 + 4*sigma1*Sigma;
    (*this)(MatrixIndexBase+2,MatrixIndexBase+2) = 4*(-sigma1*sigma1 - sigma2*sigma2 + sigma3*sigma3) + Sigma*Sigma;

    // Multiplying factor
    (*this) /= (1 + tempMatrix*tempMatrix);
    return;
}

/*! \fn void DirectionCosineMatrix::Set(const Quaternion &_qIn)
* Equation: (Ref Wertz, pg. 414)
\f[
    \left[\bf{R}\left(\bf{\bar{q}}\right)\right]
    =
    \begin{bmatrix}
    q^{2}_4+q^{2}_1-q^{2}_2-q^{2}_3 & 2\left(q_1 q_2 + q_4 q_3\right) & 2\left(q_1 q_3 - q_4 q_2\right)\\
    2\left(q_1 q_2 - q_4 q_3\right) & q^{2}_4-q^{2}_1+q^{2}_2-q^{2}_3 & 2\left(q_2 q_3 + q_4 q_1\right)\\
    2\left(q_1 q_3 + q_4 q_2\right) & 2\left(q_2 q_3 - q_4 q_1\right) & q^{2}_4-q^{2}_1-q^{2}_2+q^{2}_3
    \end{bmatrix}
\f]
*/
void DirectionCosineMatrix::Set(const Quaternion &_qIn)
{
    // Calculations done for each element to increase speed
    double q1 = _qIn(VectorIndexBase+0);
    double q2 = _qIn(VectorIndexBase+1);
    double q3 = _qIn(VectorIndexBase+2);
    double q4 = _qIn(VectorIndexBase+3);
    
    // Column 1
    (*this)(MatrixIndexBase+0,MatrixIndexBase+0) = q4*q4 + q1*q1 - q2*q2 - q3*q3;
    (*this)(MatrixIndexBase+0,MatrixIndexBase+1) = 2 * (q1*q2 - q4*q3);
    (*this)(MatrixIndexBase+0,MatrixIndexBase+2) = 2 * (q1*q3 - q4*q2);
    
    // Column 2
    (*this)(MatrixIndexBase+1,MatrixIndexBase+0) = 2 * (q1*q2 + q4*q3);
    (*this)(MatrixIndexBase+1,MatrixIndexBase+1) = q4*q4 - q1*q1 + q2*q2 -q3*q3;
    (*this)(MatrixIndexBase+1,MatrixIndexBase+2) = 2 * (q2*q3 - q4*q1);
    
    // Column 3
    (*this)(MatrixIndexBase+2,MatrixIndexBase+0) = 2 * (q1*q2 - q4*q1);
    (*this)(MatrixIndexBase+2,MatrixIndexBase+1) = 2 * (q2*q3 + q4*q1);
    (*this)(MatrixIndexBase+2,MatrixIndexBase+2) = q4*q4 - q1*q1 - q2*q2 + q3*q3; 
    return;
}

Vector DirectionCosineMatrix::GetEulerAngles(const int &_Sequence) const
{
    /*! \todo Implement DCM::GetEulerAngles function */
    return;
}

/*! \fn void DirectionCosineMatrix::GetEulerAxisAngle(Vector &_EulerAxis, double &_EulerAngle)
* Equation: Ref Wertz, pg 413-4
/f[
    \cos\Phi = \frac{1}{2}\left[tr\left(R\right)-1\right]
    \mbox{if $\sin\Phi \ne 0$, the componnets of $\hat{\bf e}}$ are given by:}
e1 = (A_{23} - A_{32})/(2\sin\Phi)
e2 = (A_{31} - A_{13})/(2\sin\Phi)
e3 = (A_{12} - A_{21})/(2\sin\Phi)
/f]
*/
void DirectionCosineMatrix::GetEulerAxisAngle(Vector &_EulerAxis, double &_EulerAngle)
{
    _EulerAngle = acos(0.5 * (trace(*this) - 1));
    if(sin(_EulerAngle) != 0)
    {
        _EulerAxis(VectorIndexBase + 0) = ((*this)(MatrixIndexBase+1,MatrixIndexBase+2)
                                           - (*this)(MatrixIndexBase+1,MatrixIndexBase+2))
        / (2 * sin(_EulerAngle));
        _EulerAxis(VectorIndexBase + 1) = ((*this)(MatrixIndexBase+2,MatrixIndexBase+0)
                                           - (*this)(MatrixIndexBase+0,MatrixIndexBase+2))
            / (2 * sin(_EulerAngle));
        _EulerAxis(VectorIndexBase + 2) = ((*this)(MatrixIndexBase+0,MatrixIndexBase+1)
                                           - (*this)(MatrixIndexBase+0,MatrixIndexBase+1))
            / (2 * sin(_EulerAngle));
    }
    else
    { // no rotation, or rotation of 180 degs, therefore arbitrary axis.
        _EulerAxis.setToValue(0.0);
        _EulerAxis(VectorIndexBase + 0) = 1;
    }
    return;
}

ModifiedRodriguezParameters DirectionCosineMatrix::GetMRP() const
{
    return ModifiedRodriguezParameters(*this);
}

Quaternion DirectionCosineMatrix::GetQuaternion() const
{
    return Quaternion(*this);
}

/** 
* \fn DirectionCosineMatrix R3(const double &_Angle)
* \ingroup DirectionCosineMatrix
* Equation:
\f[
    R_1\left(\theta\right) =
    \begin{bmatrix}
    1 & 0 & 0\\
    0 & \cos{\theta} & \sin{\theta}\\
    0 & -\sin{\theta} & \cos{\theta}
    \end{bmatrix}
    \f]
*/
DirectionCosineMatrix R1(const double &_Angle)
{
    DirectionCosineMatrix R1_Out;
    R1_Out(MatrixIndexBase+1, MatrixIndexBase+1) = cos(_Angle);
    R1_Out(MatrixIndexBase+1, MatrixIndexBase+2) = sin(_Angle);
    R1_Out(MatrixIndexBase+2, MatrixIndexBase+1) = -sin(_Angle);
    R1_Out(MatrixIndexBase+2, MatrixIndexBase+2) = cos(_Angle);
    return R1_Out;
}

/** 
* \fn DirectionCosineMatrix R3(const double &_Angle)
* \ingroup DirectionCosineMatrix
* Equation:
\f[
    R_2\left(\theta\right) =
    \begin{bmatrix}
    \cos{\theta} & 0 & -\sin{\theta}\\
    0 & 1 & 0\\
    \sin{\theta} & 0 & \cos{\theta}
    \end{bmatrix}
    \f]
*/
DirectionCosineMatrix R2(const double &_Angle)
{
    DirectionCosineMatrix R2_Out;
    R2_Out(MatrixIndexBase+0, MatrixIndexBase+0) = cos(_Angle);
    R2_Out(MatrixIndexBase+0, MatrixIndexBase+2) = -sin(_Angle);
    R2_Out(MatrixIndexBase+2, MatrixIndexBase+0) = sin(_Angle);
    R2_Out(MatrixIndexBase+2, MatrixIndexBase+2) = cos(_Angle);
    return R2_Out;
}

/** 
* \fn DirectionCosineMatrix R3(const double &_Angle)
* \ingroup DirectionCosineMatrix
* Equation:
\f[
    R_3\left(\theta\right) =
    \begin{bmatrix}
    \cos{\theta} & \sin{\theta} & 0\\
    -\sin{\theta} & \cos{\theta} & 0\\
    0 & 0 & 1
    \end{bmatrix}
    \f]
*/
DirectionCosineMatrix R3(const double &_Angle)
{
    DirectionCosineMatrix R3_Out;
    R3_Out(MatrixIndexBase+0, MatrixIndexBase+0) = cos(_Angle);
    R3_Out(MatrixIndexBase+0, MatrixIndexBase+1) = sin(_Angle);
    R3_Out(MatrixIndexBase+1, MatrixIndexBase+0) = -sin(_Angle);
    R3_Out(MatrixIndexBase+1, MatrixIndexBase+1) = cos(_Angle);
    return R3_Out;
}

//////////////////////////////////////////////////////////////////////////
// ModifiedRodriguezParameters Class
ModifiedRodriguezParameters::ModifiedRodriguezParameters():Vector(MRP_SIZE)
{
    AutoSwitch();
}

ModifiedRodriguezParameters::ModifiedRodriguezParameters(const ModifiedRodriguezParameters &_MRP):Vector(MRP_SIZE)
{
    Set(_MRP);
    AutoSwitch();
}

ModifiedRodriguezParameters::ModifiedRodriguezParameters(double _s1, double _s2, double _s3):Vector(MRP_SIZE)
{
    Set(_s1,_s2,_s3);
    AutoSwitch();
}

ModifiedRodriguezParameters::ModifiedRodriguezParameters(const Vector &_sVector):Vector(MRP_SIZE)
{
    Set(_sVector);
    AutoSwitch();
}

ModifiedRodriguezParameters::ModifiedRodriguezParameters(const DirectionCosineMatrix &_DCM):Vector(MRP_SIZE)
{
    Set(_DCM);
    AutoSwitch();
}

ModifiedRodriguezParameters::ModifiedRodriguezParameters(const Vector &_Angles, const int &_Sequence):Vector(MRP_SIZE)
{
    Set(_Angles, _Sequence);
    AutoSwitch();
}

ModifiedRodriguezParameters::ModifiedRodriguezParameters(const Vector &_EulerAxis, const double &_EulerAngle):Vector(MRP_SIZE)
{
    Set(_EulerAxis, _EulerAngle);
    AutoSwitch();
}

ModifiedRodriguezParameters::ModifiedRodriguezParameters(const Quaternion &_qIn):Vector(MRP_SIZE)
{
    Set(_qIn);
    AutoSwitch();
}

void ModifiedRodriguezParameters::Set(const ModifiedRodriguezParameters &_MRP)
{
    (*this) = _MRP;
    return;
}
void ModifiedRodriguezParameters::Set(double _s1, double _s2, double _s3)
{
    (*this)(VectorIndexBase+0) = _s1;
    (*this)(VectorIndexBase+1) = _s2;
    (*this)(VectorIndexBase+2) = _s3;
    return;
}
void ModifiedRodriguezParameters::Set(const Vector &_sVector)
{
    (*this) = _sVector(_(VectorIndexBase,VectorIndexBase+MRP_SIZE));
    return;
}

void ModifiedRodriguezParameters::Set(const DirectionCosineMatrix &_DCM)
{
    Set(_DCM.GetQuaternion());
    return;
}

void ModifiedRodriguezParameters::Set(const Vector &_EulerAngles, const int &_Sequence)
{
    /*! \todo Change implementation to calculate directly from Euler angles and not create a DCM? */
    Set(DirectionCosineMatrix(_EulerAngles, _Sequence));
    return;
}

void ModifiedRodriguezParameters::Set(const double &_Angle1, const double &_Angle2, const double &_Angle3, const int &_Sequence)
{
    /*! \todo Fix Change implementation to calculate directly from Euler angles and not create a DCM? */
    Set(DirectionCosineMatrix(_Angle1, _Angle2, _Angle3, _Sequence));
    return;
}

/*! \fn void Set(const Vector &_EulerAxis, const double &_EulerAngle)
* \ingroup ModifiedRodriguezParameters
* Equation: \f$ \bf{\sigma} = \tan{\frac{\phi}{4}}\bf{\hat{e}} \f$ (Ref Schaub99)
singluar whenever \f$\phi \rightarrow \plusminus 360^{\circ}\f$
*/
void ModifiedRodriguezParameters::Set(const Vector &_EulerAxis, const double &_EulerAngle)
{
    (*this) = (ModifiedRodriguezParameters) (tan(0.25 * _EulerAngle) * _EulerAxis);
    return;
}

/*! \fn void ModifiedRodriguezParameters::Set(const Quaternion &_qIN)
* \ingroup ModifiedRodriguezParameters
* Equation: \f$\sigma_i = \frac{\bf{q}_i}{1+q_4}\f$ for i=1,2,3 (Ref Schaub99)
*/
void ModifiedRodriguezParameters::Set(const Quaternion &_qIN)
{
    (*this) = (ModifiedRodriguezParameters) (_qIN(_(VectorIndexBase,VectorIndexBase+MRP_SIZE))
    / (1+_qIN(VectorIndexBase+3)));
    return;
}

DirectionCosineMatrix ModifiedRodriguezParameters::GetDCM() const
{
    return DirectionCosineMatrix(*this);
}

Vector ModifiedRodriguezParameters::GetEulerAngles(int _Sequence) const
{
    /*! \todo Implement ModifiedRodriguezParameters::GetEulerAngles Function */
    return;
}

void ModifiedRodriguezParameters::GetEulerAxisAngle(Vector &_EulerAxis, double &_EulerAngle) const
{
    /*! \todo Implement to directly convert and not use a temporary quaternion */
    Quaternion qTemp(*this);
    qTemp.GetEulerAxisAngle(_EulerAxis, _EulerAngle);
    return;
}

Quaternion ModifiedRodriguezParameters::GetQuaternion() const
{
    return Quaternion(*this);
}

void ModifiedRodriguezParameters::Switch(int _SwitchThreshold)
{
    if (norm2((Vector)*this) > _SwitchThreshold)
        (*this) = ShadowSet();
    return;
}

void ModifiedRodriguezParameters::AutoSwitch(bool _SwitchBoolean)
{
    m_AutoSwitch = _SwitchBoolean;
    return;
}

/*! \fn ModifiedRodriguezParameters ModifiedRodriguezParameters::ShadowSet()
* \ingroup ModifiedRodriguezParameters
* Equation: /f$ \bf{\sigma}^{S} = - \frac{1}{\left|\bf{\sigma}\right|^2}\bf{\sigma} /f$ (Ref Schaub99)
*/
ModifiedRodriguezParameters ModifiedRodriguezParameters::ShadowSet()
{
    return (ModifiedRodriguezParameters)(-(*this)(_) / pow(norm2(*this),2));
}

/*! \fn ModifiedRodriguezParameters ModifiedRodriguezParameters::operator+ (const DirectionCosineMatrix& _MRP2) const
* \ingroup ModifiedRodriguezParameters
* Equation: Summing two MRP vectors /f$\bf{\sigma'}/f$ and /f$\bf{\sigma''}/f$:
/f[
    \bf{\sigma} = \frac{\left(1-\left|\bf{\sigma'}\right|^2\right)\bf{\sigma''}+\left(1-\left|\bf{\sigma''\right|^2\right)\bf{\sigma'}-2\bf{\sigma''} \times \bf{\sigma'}}{1+\left|\bf{\sigma'}\right|^2\left|\bf{\sigma''}\right|^2-2\bf{\sigma'} \dot \bf{\sigma''}}
/f]
*/
ModifiedRodriguezParameters ModifiedRodriguezParameters::operator+ (const ModifiedRodriguezParameters &_MRP2) const
{
    ModifiedRodriguezParameters MRPsum;
    MRPsum(_) = (1-pow(norm2(*this),2)) * _MRP2
        + (1-pow(norm2(_MRP2),2)) * (*this)
              - 2*crossP(_MRP2,(*this));
    MRPsum(_) = MRPsum / (1 + pow(norm2(*this),2) * pow(norm2(_MRP2),2)
        - 2 * (*this).dot( _MRP2));
    return MRPsum;
}

/*! \fn ModifiedRodriguezParameters ModifiedRodriguezParameters::operator- (const DirectionCosineMatrix& _MRP2) const
* \ingroup ModifiedRodriguezParameters
* Equation: Relative MRP vector /f$\bf{\sigma''} = \bf{\sigma} - \bf{\sigma'}/f$ (Ref Schaub99):
/f[
    \bf{\sigma''} = \frac{\left(1-\left|\bf{\sigma'}\right|^2\right)\bf{\sigma}-\left(1-\left|\bf{\sigma\right|^2\right)\bf{\sigma'}+2\bf{\sigma} \times \bf{\sigma'}}{1+\left|\bf{\sigma'}\right|^2\left|\bf{\sigma}\right|^2+2\bf{\sigma'} \dot \bf{\sigma}}
/f]
*/
ModifiedRodriguezParameters ModifiedRodriguezParameters::operator- (const ModifiedRodriguezParameters &_MRP2) const
{
    ModifiedRodriguezParameters MRPsum;
    MRPsum(_) = (1-pow(norm2(_MRP2),2)) * (*this)
        + (1-pow(norm2(*this),2)) * _MRP2
        - 2*crossP((*this), _MRP2);
    MRPsum(_) = MRPsum / ((1 + pow(norm2(_MRP2),2)) * pow(norm2(*this),2)
                        - 2 * _MRP2.dot(*this));
    return MRPsum;
}

//////////////////////////////////////////////////////////////////////////
// Quaternion Class
Quaternion::Quaternion():Vector(QUATERNION_SIZE)
{
    (*this).setToValue(0.0);
    (*this)(VectorIndexBase+3) = 1.0;	
}

Quaternion::Quaternion(double _q1, double _q2, double _q3, double _q4):Vector(QUATERNION_SIZE)
{
    Set(_q1, _q2, _q3, _q4);
}

Quaternion::Quaternion(const Vector &_qVector):Vector(QUATERNION_SIZE)
{
    Set(_qVector);
}

Quaternion::Quaternion(const DirectionCosineMatrix &_DCM):Vector(QUATERNION_SIZE)
{
    Set(_DCM);
}

Quaternion::Quaternion(const Vector &_EulerAngles, const int &_Sequence):Vector(QUATERNION_SIZE)
{
    Set(_EulerAngles, _Sequence);
    Normalize();
}

Quaternion::Quaternion(const Vector &_EulerAxis, const double &_EulerAngle):Vector(QUATERNION_SIZE)
{
    Set(_EulerAxis, _EulerAngle);
}

Quaternion::Quaternion(const ModifiedRodriguezParameters &_MRP):Vector(QUATERNION_SIZE)
{
    Set(_MRP);
}

void Quaternion::Set(const Quaternion &_qIn)
{
    (*this) = _qIn;
    return;
}

void Quaternion::Set(double _q1, double _q2, double _q3, double _q4)
{
    (*this)(VectorIndexBase+0) = _q1;	
    (*this)(VectorIndexBase+1) = _q2;	
    (*this)(VectorIndexBase+2) = _q3;	
    (*this)(VectorIndexBase+3) = _q4;	
    Normalize();
    return;
}

void Quaternion::Set(const Vector &_qVector)
{
    (*this)(VectorIndexBase+0) = _qVector(VectorIndexBase+0);	
    (*this)(VectorIndexBase+1) = _qVector(VectorIndexBase+1);	
    (*this)(VectorIndexBase+2) = _qVector(VectorIndexBase+2);	
    (*this)(VectorIndexBase+3) = _qVector(VectorIndexBase+3);
    return;
}

/*! \fn void Quaternion::Set(const DirectionCosineMatrix &_DCM)
* Equation: Ref Hughes p. 18
\f[
    q_4 = \plusminus \frac{1}{2}\left(1+R_{11}+R_{22}+R_{33}\right)^{\frac{1}{2}}\\
    \bf{q} = \frac{1}{q_4}
    \begin{bmatrix}
    R_{23}-R{32} \\ R_{31}-R{13} \\ R_{12}-R{21}
    \end{bmatrix}\\
    \bf{\bar{q}} = \begin{bmatrix} \bf{q} \\ q_4 \end{bmatrix}
/f]
*/
void Quaternion::Set(const DirectionCosineMatrix &_DCM)
{
    double q4 = 0.5 * ::sqrt(1 + trace(_DCM));
    (*this)(VectorIndexBase+0) = _DCM(MatrixIndexBase+1,MatrixIndexBase+2)
        - _DCM(MatrixIndexBase+2,MatrixIndexBase+1);
    (*this)(VectorIndexBase+1) = _DCM(MatrixIndexBase+2,MatrixIndexBase+0)
        - _DCM(MatrixIndexBase+0,MatrixIndexBase+2);
    (*this)(VectorIndexBase+2) = _DCM(MatrixIndexBase+0,MatrixIndexBase+1)
        - _DCM(MatrixIndexBase+1,MatrixIndexBase+0);
    (*this) /= (4 * q4);
    Normalize();
    return;
}

void Quaternion::Set(const Vector &_EulerAngles, const int &_Sequence)
{
    /*! \todo Implement Quaternion::Set(EulerAngles, Sequence) as individual calcs instead of multiple conversions */
    Set(DirectionCosineMatrix(_EulerAngles, _Sequence));
    return;
}

/*! \fn void Quaternion::Set(const Vector &_EulerAxis, const double &_EulerAngle)
* Equation: \f$ \bf{q}_i = \hat{e}_i \sin{\frac{\Phi}{2}} q_4 = \cos{\frac{\Phi}{2}} \f$ for i=1,2,3
*/
void Quaternion::Set(const Vector &_EulerAxis, const double &_EulerAngle)
{
    (*this)(_(VectorIndexBase+0,VectorIndexBase+2)) = _EulerAxis * sin(0.5 * _EulerAngle);		
    (*this)(VectorIndexBase+3) = cos(0.5 * _EulerAngle);
    return;
}

/*! \fn void Quaternion::Set(const ModifiedRodriguezParameters &_MRP)
* Equation: \f$ \bf{q}_i = \frac{2\sigma_i}{1+\sigma^2} q_4 = \frac{1-\sigma^2}{1+\sigma^2} \f$ for i=1,2,3 (Ref Schaub99)
*/
void Quaternion::Set(const ModifiedRodriguezParameters &_MRP)
{
    Matrix tempMatrix = (~_MRP) * (_MRP);
    double temp = (double)(1 + tempMatrix(MatrixIndexBase,MatrixIndexBase));
    (*this)(_(VectorIndexBase+0,VectorIndexBase+2)) = 2 * _MRP / temp;		
    (*this)(VectorIndexBase+3) = double(1 - tempMatrix(MatrixIndexBase,MatrixIndexBase)) /temp;
    return;
}

DirectionCosineMatrix Quaternion::GetDCM() const
{
    return DirectionCosineMatrix(*this);
}

Vector Quaternion::GetEulerAngles(const int &_Sequence) const
{
    /*! \todo Implement Quaternion::GetEulerAngles function */
    return;
}

/*! \fn void Quaternion::GetEulerAxisAngle(Vector &_EulerAxis, double &_EulerAngle)
* Equation: /f$\Phi = 2\cos^{-1}{q_4} \hat{e}_i = \bf{q}_i\sin{\frac{\Phi}{2}}/f$ (Ref Schaub99)
*/
void Quaternion::GetEulerAxisAngle(Vector &_EulerAxis, double &_EulerAngle)
{
    _EulerAngle = 2.0 * acos((*this)(VectorIndexBase+3));
    _EulerAxis = (*this)(_(VectorIndexBase+0,VectorIndexBase+2)) * sin(0.5 * _EulerAngle);
    return;
}

ModifiedRodriguezParameters Quaternion::GetMRP() const
{
    return ModifiedRodriguezParameters(*this);
}

void Quaternion::Normalize()
{
    /*! \todo Add Normalize() to Vector Class */
    normalize(*this);
    return;
}

/*! \fn Quaternion Quaternion::operator+ (const Quaternion& _quat2) const
* Equation: successive rotations of \f$\bf{q'}\f$ and \f$\bf{q''}\f$ (Ref Schaub99)
\f[
\begin{bmatrix}
q_1 \\ q_2 \\ q_3 \\ q_4
\end{bmatrix}
=
\begin{bmatrix}
q'_1 & q'_4 & -q'_3 & q'_2\\
q'_2 & q'_3 & q'_4 & -q'_1\\
q'_3 & -q'_2 & q'_1 & q'_4\\
q'_4 & -q'_1 & -q'_2 & -q'_3
\end{bmatrix}
\begin{bmatrix}
q''_1 \\ q''_2 \\ q''_3 \\ q''_4
\end{bmatrix}
\f]
*/
Quaternion Quaternion::operator+ (const Quaternion& _quat2) const
{
    Matrix qSkewed(4,4);
    // Column 1
    qSkewed(_,MatrixIndexBase+0) = (*this);
    // Column 2
    qSkewed(MatrixIndexBase+0,MatrixIndexBase+1) =  (*this)(VectorIndexBase+0);	
    qSkewed(MatrixIndexBase+1,MatrixIndexBase+1) =  (*this)(VectorIndexBase+2);
    qSkewed(MatrixIndexBase+2,MatrixIndexBase+1) = -(*this)(VectorIndexBase+1);
    qSkewed(MatrixIndexBase+3,MatrixIndexBase+1) = -(*this)(VectorIndexBase+3);
    // Column 3
    qSkewed(MatrixIndexBase+0,MatrixIndexBase+2) = -(*this)(VectorIndexBase+1);	
    qSkewed(MatrixIndexBase+1,MatrixIndexBase+2) =  (*this)(VectorIndexBase+2);
    qSkewed(MatrixIndexBase+2,MatrixIndexBase+2) =  (*this)(VectorIndexBase+3);
    qSkewed(MatrixIndexBase+3,MatrixIndexBase+2) = -(*this)(VectorIndexBase+0);
    // Column 4
    qSkewed(MatrixIndexBase+0,MatrixIndexBase+3) =  (*this)(VectorIndexBase+1);	
    qSkewed(MatrixIndexBase+1,MatrixIndexBase+3) = -(*this)(VectorIndexBase+0);
    qSkewed(MatrixIndexBase+2,MatrixIndexBase+3) =  (*this)(VectorIndexBase+3);
    qSkewed(MatrixIndexBase+3,MatrixIndexBase+3) = -(*this)(VectorIndexBase+2);

    return Quaternion(qSkewed * _quat2);
}

/*! \fn Quaternion Quaternion::operator- (const Quaternion& _quat2) const
* Equation: subtracting \f$\bf{q'}\f$ from \f$\bf{q''}\f$ (Ref Schaub99)
\f[
    \begin{bmatrix}
    q_1 \\ q_2 \\ q_3 \\ q_4
    \end{bmatrix}
    =
    \begin{bmatrix}
    -q'_4 & q'_4 & q'_3 & -q'_2\\
    -q'_2 & -q'_3 & q'_4 & q'_1\\
    -q'_3 & -q'_2 & -q'_1 & q'_4\\    
    q'_4 & q'_1 & q'_2 & q'_3
    \end{bmatrix}
    \begin{bmatrix}
    q''_1 \\ q''_2 \\ q''_3 \\ q''_4
    \end{bmatrix}
    \f]
*/
Quaternion Quaternion::operator- (const Quaternion& _quat2) const
{
    Matrix qSkewed(4,4);
    // Column 1
    qSkewed(MatrixIndexBase+0,MatrixIndexBase+0) = -(*this)(VectorIndexBase+0);
    qSkewed(MatrixIndexBase+0,MatrixIndexBase+1) = -(*this)(VectorIndexBase+1);
    qSkewed(MatrixIndexBase+0,MatrixIndexBase+2) = -(*this)(VectorIndexBase+2);
    qSkewed(MatrixIndexBase+0,MatrixIndexBase+3) =  (*this)(VectorIndexBase+3);
    // Column 2
    qSkewed(MatrixIndexBase+0,MatrixIndexBase+1) =  (*this)(VectorIndexBase+4);	
    qSkewed(MatrixIndexBase+1,MatrixIndexBase+1) = -(*this)(VectorIndexBase+2);
    qSkewed(MatrixIndexBase+2,MatrixIndexBase+1) =  (*this)(VectorIndexBase+1);
    qSkewed(MatrixIndexBase+3,MatrixIndexBase+1) =  (*this)(VectorIndexBase+0);
    // Column 3
    qSkewed(MatrixIndexBase+0,MatrixIndexBase+2) =  (*this)(VectorIndexBase+2);	
    qSkewed(MatrixIndexBase+1,MatrixIndexBase+2) =  (*this)(VectorIndexBase+3);
    qSkewed(MatrixIndexBase+2,MatrixIndexBase+2) = -(*this)(VectorIndexBase+0);
    qSkewed(MatrixIndexBase+3,MatrixIndexBase+2) =  (*this)(VectorIndexBase+1);
    // Column 4
    qSkewed(MatrixIndexBase+0,MatrixIndexBase+3) = -(*this)(VectorIndexBase+1);	
    qSkewed(MatrixIndexBase+1,MatrixIndexBase+3) =  (*this)(VectorIndexBase+0);
    qSkewed(MatrixIndexBase+2,MatrixIndexBase+3) =  (*this)(VectorIndexBase+3);
    qSkewed(MatrixIndexBase+3,MatrixIndexBase+3) =  (*this)(VectorIndexBase+2);

    return Quaternion((~qSkewed) * _quat2);
}



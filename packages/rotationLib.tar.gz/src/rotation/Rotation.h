//////////////////////////////////////////////////////////////////////////////////////////////////
/*! \file Rotation.h
 *  \brief Rotation toolkit.
 *  \brief Provides a set of functions to use Rotation matrices
 *         and their various representations.
 *  \author Andrew Turner <ajturner@vt.edu>
 *  \author Chris Hall <cdhall@vt.edu>
 *  \version 0.1
 *  \date    2001-2003
//////////////////////////////////////////////////////////////////////////////////////////////////
 *  \warning 
 *  \todo Implement Gibbs vector representation
 *  \todo Wrap Rotation library in a namespace
 */
//////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef ROTATION_H
#define ROTATION_H

#include "Matrix.h"

// Prototype definitions of classes in Rotation Toolbox
class Quaternion;
class DirectionCosineMatrix;
class ModifiedRodriguezParameters;
class Rotation;			


/*! Number of elements in a quaternion vector */
const int QUATERNION_SIZE = 4;
/*! Number of elements in a MRP vector */
const int MRP_SIZE = 3;
/*! Number of elements in a DCM row or column */
const int DCM_SIZE = 3;


//////////////////////////////////////////////////////////////////////////////////////////////////
/** @defgroup AttitudeRepresentation Kinematic Toolbox
* The Kinematics Toolbox is a collection of attitude representation class definitions that are meant to
* assist in the implementation of spacecraft analysis and operation code. 
* @{
*/

//////////////////////////////////////////////////////////////////////////////////////////////////
/** @defgroup DirectionCosineMatrix Direction Cosine Matrix
* @ingroup AttitudeRepresentation
*  The 3x3 direction cosine matrix attitude representation
*  @{
*/
class DirectionCosineMatrix:public Matrix
{
public:
    /** 
    * Create a DCM equal to the identity matrix [1,0,0;0,1,0;0,0,1].
    *  @return 3x3 Direction Cosine Matrix equal to the identity matrix. 
    */
    DirectionCosineMatrix();
    
    /** 
    * Default deconstructor. 
    */
    virtual ~DirectionCosineMatrix() {}

    /** 
    * Create a copy of a DCM from an existing DCM.
    * @param _DCM 3x3 Direction Cosine Matrix to be copied.
    */
    DirectionCosineMatrix(const DirectionCosineMatrix &_DCM);

    /** 
        * Create a copy of a DCM from an existing matrix of DCM values.
        * @param _DCM 3x3 matrix of DCM values to be copied.
        */
    DirectionCosineMatrix(const Matrix &_DCM);

    /** 
        * Create a Direction Cosine Matrix (DCM) from Euler Angles.
        * @param _EulerAngles 3x1 matrix of Euler Angles. [rad]
        * @param _Sequence Euler angle rotation sequence. (ie 123, 213, 313, 321, etc).
        */
    DirectionCosineMatrix(const Vector &_EulerAngles, const int &_Sequence);

    /** 
        * Create a Direction Cosine Matrix (DCM) from an Euler Axis and rotation.
        * @param _EulerAxis 3x1 Euler Axis vector (\f$\hat{e}\f$).
        * @param _EulerAngle Angle rotation about axis (\f$\Phi\f$)[rad].
        */
    DirectionCosineMatrix(const Vector &_EulerAxis, const double &_EulerAngle);

    /** 
        * Create a Direction Cosine Matrix (DCM) from Euler Angles.
        * @param _Angle1 first angles in Euler angle set. [rad]
        * @param _Angle2 second angles in Euler angle set. [rad]
        * @param _Angle3 third angles in Euler angle set. [rad]
        * @param _Sequence Euler angle rotation sequence. (ie 123, 213, 313, 321, etc).
        */
    DirectionCosineMatrix(const double &_Angle1, const double &_Angle2, const double &_Angle3, const int &_Sequence);

    /** 
        * Create a Direction Cosine Matrix (DCM) from a vector of Modified Rodriguez Parameters (MRP).
        * @param _MRP 3x1 MRP to be converted.
        */
    DirectionCosineMatrix(const ModifiedRodriguezParameters &_MRP);

    /** 
        * Create a Direction Cosine Matrix (DCM) from a quaternion.
        * @param _quat 4x1 quaternion to be converted.
        *  @return 3x3 Direction Cosine Matrix. 
        */
    DirectionCosineMatrix(const Quaternion &_quat);
    
    /** 
        * Set a DCM to a copy of another DCM.
        * @param _DCM 3x3 DCM to be copied.
        */
    void Set(const DirectionCosineMatrix &_DCM);

    /** 
        * Set the DCM to the transformation of set of Euler Angles.
        * @param _EulerAngles 3x1 matrix of Euler Angles. [rad]
        * @param _Sequence Euler angle rotation sequence. (ie 123, 213, 313, 321, etc).
        */
    void Set(const Vector &_EulerAngles, const int &_Sequence);

    /** 
        * Set the DCM to the transformation of set of Euler Angles.
        * @param _Angle1 first angles in Euler angle set. [rad]
        * @param _Angle2 second angles in Euler angle set. [rad]
        * @param _Angle3 third angles in Euler angle set. [rad]
        * @param _Sequence Euler angle rotation sequence. (ie 123, 213, 313, 321, etc).
        */
    void Set(const double &_Angle1, const double &_Angle2, const double &_Angle3, const int &_Sequence);

    /** 
        * Set the DCM to the transformation of an Euler Axis and Angle.
        * @param _EulerAxis 3x1 Euler Axis vector (\f$\hat{e}\f$).
        * @param _EulerAngle Angle rotation about axis (\f$\Phi\f$)[rad].
        */
    void Set(const Vector &_EulerAxis, const double &_EulerAngle);

    /** 
        * Set the DCM to the transformation of Modified Rodriguez Paramaters (MRP).
        * @param _MRP 3x1 matrix of Modified Rodriguez Parameters (MRP).
        */
    void Set(const ModifiedRodriguezParameters &_MRP);
    
    /** 
        * Set a DCM to the transformation of a quaternion.
        * Equation: 
        * @param _qIn 4x1 quaternion to be converted.
        */
    void Set(const Quaternion &_qIn);

    /** 
        * Convert a DCM to a set of Euler Angles.
        * @param _Sequence Euler angle rotation sequence. (ie 123, 213, 313, 321, etc).
        * @return (3 x 1) Euler Angles based on given rotation sequence. 
        */
    Vector GetEulerAngles(const int &_Sequence) const;

    /** 
        * Convert the DCM to an Euler Axis and Angle.
        * @param _EulerAxis 3x1 Euler Axis vector (\f$\hat{e}\f$).
        * @param _EulerAngle Angle rotation about axis (\f$\Phi\f$)[rad].
        */
    void GetEulerAxisAngle(Vector &_EulerAxis, double &_EulerAngle);
    
    /** 
        * Convert a DCM to an MRP representation.
        * @return (3 x 1) converted MRP. 
        */
    ModifiedRodriguezParameters GetMRP() const;
    
    /** 
        * Convert a DCM to a quaternion representation.
        *  @return (4 x 1) converted quaternion. 
        */
    Quaternion GetQuaternion() const;
    
    /** 
        * Determine the successive rotation from the summation of two DCMs.
        * @param _DCM2 DCM to be summed with.
        */
    DirectionCosineMatrix operator+ (const DirectionCosineMatrix& _DCM2) const;

    /** 
        * Determine the relative rotation from the difference of two DCMs.
        * @param _DCM2 DCM to be differenced with.
        */
    DirectionCosineMatrix operator- (const DirectionCosineMatrix& _DCM2) const;

    /** 
        * Determine the successive rotation of the DCMS through multiplication.
        * @param _DCM2 DCM to be multiplied by.
        */
    inline DirectionCosineMatrix operator* (const DirectionCosineMatrix& _DCM2) const {return (*this) * _DCM2;}

    /** 
        * Determines the inverse of a DCM by taking the transpose (same operation).
        * @return Inverse (transpose) of DCM.
        */
    inline DirectionCosineMatrix operator~ () {return operator~();};
    
};

/** 
* Calculates the principal rotation of the angle about the 1-axis.
* @param _Angle Angle of Rotation [rad].
*/
DirectionCosineMatrix R1(const double &_Angle);

/** 
* Calculates the principal rotation of the angle about the 2-axis.
* @param _Angle Angle of Rotation [rad].
*/
DirectionCosineMatrix R2(const double &_Angle);

/** 
* Calculates the principal rotation of the angle about the 3-axis.
* @param _Angle Angle of Rotation [rad].
*/
DirectionCosineMatrix R3(const double &_Angle);
/** @} */ // end of DirectionCosineMatrix

//////////////////////////////////////////////////////////////////////////////////////////////////
/** @defgroup ModifiedRodriguezParameters Modified Rodriguez Parameters
* @ingroup AttitudeRepresentation
*  The 3x1 Modified Rodriguez Parameters attitude representation
*  @{
*/
class ModifiedRodriguezParameters:public Vector
{
public:
    /** 
    * Default Constructor.
    * Create an MRP set with intial value of [0,0,0]^T.
    */
    ModifiedRodriguezParameters();

    /** 
    * Copy Constructor.
    * Create a copy of an MRP set.
    */
    ModifiedRodriguezParameters(const ModifiedRodriguezParameters &_MRP);
    
    /** 
    * Create an MRP set based on 3 values.
    * @param _s1 first MRP value.
    * @param _s2 second MRP value.
    * @param _s3 third MRP value.
    */
    ModifiedRodriguezParameters(double _s1, double _s2, double _s3);
    
    /** 
        * Create an MRP set from a vector 3 values.
        * @param _sVector 3x1 vector of MRP values.
        */
    ModifiedRodriguezParameters(const Vector &_sVector);

    /** 
        * Create an MRP set converted from a Direction Cosine Matrix (DCM).
        * @param _DCM 3x3 Direction Cosine Matrix (DCM) to be converted.
        */
    ModifiedRodriguezParameters(const DirectionCosineMatrix &_DCM);

    /** 
        * Create an MRP set from an Euler Angle sequence.
        * @param _Angles 3x1 matrix of euler angles. [rad]
        * @param _Sequence Euler angle rotation sequence. (ie 123, 213, 313, 321, etc).
        */
    ModifiedRodriguezParameters(const Vector &_Angles, const int &_Sequence);

    /** 
        * Create the MRP from an Euler Axis and Angle.
        * @param _EulerAxis 3x1 Euler Axis vector (\f$\hat{e}\f$).
        * @param _EulerAngle Angle rotation about axis (\f$\Phi\f$)[rad].
        */
    ModifiedRodriguezParameters(const Vector &_EulerAxis, const double &_EulerAngle);
    
    /** 
        * Create an MRP set converted from a quaternion.
        * @param _DCM 4x1 quaternion to be converted.
        */
    ModifiedRodriguezParameters(const Quaternion &_qIN);

    /** Set the MRP to the copy of an existing MRP vector
        * @param _MRP MRP Vector to be copied
        */
    void Set(const ModifiedRodriguezParameters &_MRP);
    
    /** 
        * Set the MRP vector based on 3 values.
        * @param _s1 first MRP value.
        * @param _s2 second MRP value.
        * @param _s3 third MRP value.
        */
    void Set(double _s1, double _s2, double _s3);

    /** 
        * Set the MRP set from a vector 3 values.
        * @param _sVector 3x1 vector of MRP values.
        */
    void Set(const Vector &_sVector);
    
    /** 
        * Set the MRP from a converted Direction Cosine Matrix (DCM).
        * @param _DCM 3x3 Direction Cosine Matrix (DCM) to be converted
        */
    void Set(const DirectionCosineMatrix &_DCM);

    /** 
        * Set the MRP from the transformation of set of Euler Angles.
        * @param _EulerAngles 3x1 matrix of Euler Angles. [rad]
        * @param _Sequence Euler angle rotation sequence. (ie 123, 213, 313, 321, etc).
        */
    void Set(const Vector &_EulerAngles, const int &_Sequence);

    /** 
        * Set the MRP from the transformation of set of Euler Angles.
        * @param _Angle1 first angles in Euler angle set. [rad]
        * @param _Angle2 second angles in Euler angle set. [rad]
        * @param _Angle3 third angles in Euler angle set. [rad]
        * @param _Sequence Euler angle rotation sequence. (ie 123, 213, 313, 321, etc).
        */
    void Set(const double &_Angle1, const double &_Angle2, const double &_Angle3, const int &_Sequence);

    /** 
        * Set the MRP from the transformation of an Euler Axis and Angle.
        * @param _EulerAxis 3x1 Euler Axis vector (\f$\hat{e}\f$).
        * @param _EulerAngle Angle rotation about axis (\f$\Phi\f$)[rad].
        */
    void Set(const Vector &_EulerAxis, const double &_EulerAngle);
    
    /** 
        * Set the MRPs from a converted quaternion.
        * @param _qIN 4x1 quaternion to be converted
        */
    void Set(const Quaternion &_qIN);

    /** 
        * Convert the MRP vector to a Direction Cosine Matrix (DCM).
        * @return 3x3 Direction Cosine Matrix.
        */
    DirectionCosineMatrix GetDCM() const;

    /** 
        * Convert the MRP vector to a set of Euler Angles.
        * @param _Sequence Euler angle rotation sequence. (ie 123, 213, 313, 321, etc).
        * @return 3x1 vector of euler angles.
        */
    Vector GetEulerAngles(int _Sequence) const;

    /** 
        * Convert the MRP vector to the Euler Axis and Angle set.
        * @param _Sequence Euler angle rotation sequence. (ie 123, 213, 313, 321, etc).
        * @return 3x1 vector of euler angles.
        */
    void GetEulerAxisAngle(Vector &_EulerAxis, double &_EulerAngle) const;
    
    /** 
        * Convert the MRP vector to a quaternion.
        * @return 4x1 quaternion.
        */
    Quaternion GetQuaternion() const;
    
    /** 
        * Switches the MRP vector to the shortest rotational distance back to the origin
        *	using the shadow set if the magnitude of the vector is greater than the input value S.
        * @param _SwitchThreshold magnitude of the MRP vector at which the set is switched. A positive scalar number.
        */
    void Switch(int _SwitchThreshold = 1);

    /** 
        * Sets the MRP set to automatically switch between the normal set and the shadow set
        * 	based on the shortest rotational distance to the origin.
        * @param _SwitchBoolean boolean value where TRUE turns on switching, and FALSE turns off switching.
        */
    void AutoSwitch(bool _SwitchBoolean = true);

    /** 
        * Calculates and returns the MRP shadow set.
        * @return MRP shadow set (3x1).
        */
    ModifiedRodriguezParameters ShadowSet();

    /** 
        * Determine the successive rotation from the summation of two MRP vectors.
        * @param _MRP2 MRP vector to be summed with.
        */
    ModifiedRodriguezParameters operator+ (const ModifiedRodriguezParameters &_MRP2) const;

    /** 
        * Determine the relative rotation from the difference of two MRP vectors.
        * @param _MRP2 MRP vector to be differenced with.
        */
    ModifiedRodriguezParameters operator- (const ModifiedRodriguezParameters& _MRP2) const;
    /** @} */ // end of MRPOperators
private:
    /** 
        * Configuration for auto-switching to shadow set.
        */
    bool m_AutoSwitch;
};
/** @} */ // end of ModifiedRodriguezParameters

//////////////////////////////////////////////////////////////////////////////////////////////////
/** @defgroup Quaternion Quaternion Attitude Representation
* @ingroup AttitudeRepresentation
*  The non-singular, redundant Euler parameter (quaternion) vector
\f[
    \bf{q} = {\bf{a}}\sin \frac{\Phi}{2}\\
    q_4  = \cos \frac{\Phi}{2}\\
    {\bf{\bar q}} = \left[{\begin{array}{*{20}c}
        {\bf{q}} & {q_4 }  \\
        \end{array}}
        \right]^T
    \f]
for i=1,2,3
*  @{
    */
class Quaternion:public Vector
{
public:
    /** 
    * Create a quaternion with initial value of [0,0,0,1]^T.
    *  @return (double)  - (4 x 1) quaternion = [0,0,0,1]^T. 
    */
    Quaternion();

    /**
    * Create a quaternion with initial values.
    * @param _q1 first quaternin parameter
    * @param _q2 second quaternin parameter
    * @param _q3 third quaternin parameter
    * @param _q4 fourth quaternin parameter
    *  @return (double)  - (4 x 1) quaternion = [_q1,_q2,_q3,_q4]^T. 
    */
    Quaternion(double _q1, double _q2, double _q3, double _q4);

    /** 
        * Create a quaternion with initial value of the input 4x1 matrix.
        * @param _qMatrix 4x1 matrix of quaternion elements.
        *  @return (double)  - (4 x 1) quaternion. 
        */
    Quaternion(const Vector &_qVector);

    /** 
        * Create a quaternion from a direction cosine matrix (DCM).
        * @param _DCM 3x3 Direction Cosine Matrix to be transformed.
        *  @return (double)  - (4 x 1) quaternion. 
        */
    Quaternion(const DirectionCosineMatrix &_DCM);

    /** 
        * Create a quaternion from a set of Euler Angles and Sequence.
        * @param _EulerAngles 3x1 matrix of Euler Angles. [rad]
        * @param _Sequence Euler angle rotation sequence. (ie 123, 213, 313, 321, etc).
        */
    Quaternion(const Vector &_EulerAngles, const int &_Sequence);

    /** 
        * Create a quaternion from the transformation about an Euler Axis by a set angle.
        * @param _EulerAxis 3x1 Euler Axis vector.
        * @param _EulerAngle Angle rotation about axis [rad].
        */
    Quaternion(const Vector &_EulerAxis, const double &_EulerAngle);

    /** 
        * Create a Quaternion from the transformation of Modified Rodriguez Paramaters (MRP).
        * @param _MRP 3x1 matrix of Modified Rodriguez Parameters (MRP).
        */
    Quaternion(const ModifiedRodriguezParameters &_MRP);

    /** 
        * Normalizes a quaternion so that \f${\bf{\bar q}}^T {\bf{\bar q}}=1$\f. 
        */
    void Normalize();

    /** 
        * Set the quaternion to a copy of another quaternion.
        * @param _qIn Quaternion to be copied.
        */
    void Set(const Quaternion &_qIn);

    /**
        * Sets the quaternion to the values specified.
        * @param _q1 first quaternin parameter
        * @param _q2 second quaternin parameter
        * @param _q3 third quaternin parameter
        * @param _q4 fourth quaternin parameter
        */
    void Set(double _q1, double _q2, double _q3, double _q4);

    /** 
        * Sets the quaternion with the values of the input 4x1 matrix.
        * @param _qMatrix 4x1 matrix of quaternion elements.
        */
    void Set(const Vector &_qVector);

    /** 
        * Sets the current quaternion from a converted Direction Cosine Matrix (DCM).
        * @param _DCM 3x3 DCM to be converted.
        */
    void Set(const DirectionCosineMatrix &_DCM);

    /** 
        * Set the quaternion to the transformation of set of Euler Angles.
        * @param _EulerAngles 3x1 matrix of Euler Angles. [rad]
        * @param _Sequence Euler angle rotation sequence. (ie 123, 213, 313, 321, etc).
        */
    void Set(const Vector &_EulerAngles, const int &_Sequence);

    /** 
        * Set the quaternion to the transformation about an Euler Axis by a set angle.
        * @param _EulerAxis 3x1 Euler Axis vector (\f$\hat{e}\f$).
        * @param _EulerAngle Angle rotation about axis (\f$\Phi\f$)[rad].
        */
    void Set(const Vector &_EulerAxis, const double &_EulerAngle);

    /** 
        * Set the Quaternion to the transformation of Modified Rodriguez Paramaters (MRP).
        * @param _MRP 3x1 matrix of Modified Rodriguez Parameters (MRP).
        */
    void Set(const ModifiedRodriguezParameters &_MRP);

    /** 
        * Convert the quaternion to a Direction Cosine Matrix (DCM).
        * Uses the DirectionCosineMatrix(Quaternion) constructor.
        * @return 3x3 Direction Cosine Matrix.
        */
    DirectionCosineMatrix GetDCM() const;

    /** 
        * Convert the quaternion to a set of Euler Angles.
        * @param _Sequence Euler angle rotation sequence. (ie 123, 213, 313, 321, etc).
        * @return (3 x 1) Euler Angles based on given rotation sequence (\f$\theta_i\f$)[rad] 
        */
    Vector GetEulerAngles(const int &_Sequence) const;

    /** 
        * Convert the quaternion to an Euler Axis and Angle.
        * @param _EulerAxis 3x1 Euler Axis vector (\f$\hat{e}\f$).
        * @param _EulerAngle Angle rotation about axis (\f$\Phi\f$)[rad].
        */
    void GetEulerAxisAngle(Vector &_EulerAxis, double &_EulerAngle);

    /** 
        * Convert the quaternion to an MRP representation.
        * Uses the ModifiedRodriguezParameters(Quaternion) constructor.
        * @return (3 x 1) converted MRP. 
        */
    ModifiedRodriguezParameters GetMRP() const;

    //////////////////////////////////////////////////////////////////////
    /** 
        * Determine the successive rotation from the summation of two quaternions.
        * @param _quat2 Quaternion to be summed with.
        */
    Quaternion operator+ (const Quaternion& _quat2) const;

    /** 
        * Determine the relative rotation from the difference of two quaternions.
        * @param _quat2 Quaternion to be differenced with.
        */
    Quaternion operator- (const Quaternion& _quat2) const;

private:

};
/** @} */ // end of Quaternion

//////////////////////////////////////////////////////////////////////////////////////////////////
/** @defgroup Rotation Rotation
*  A generalized rotation class to represent any attitude coordinate transformation
*  @{
    */
class Rotation
{
public:
    // RotationConstructors
    /** 
    * Default Constructor.
    * Create a Rotation with no offset.
    */
    Rotation();

    /** 
    * Create a Rotation from a direction cosine matrix.
    * @param _inMatrix 3x3 matrix of Direction Cosine Matrix (DCM) values.
    */
    Rotation(const Matrix &_inMatrix);

    /** 
        * Create a Rotation from a direction cosine matrix.
        * @param _DCM instance of Direction Cosine Matrix (DCM) class.
        */
    Rotation(const DirectionCosineMatrix &_DCM);

    /** 
        * Create a Rotation from an euler angle sequence.
        * @param _Angles 3x1 matrix of euler angles.
        * @param _Sequence Euler angle rotation sequence. (ie 123, 213, 313, 321, etc).
        */
    Rotation(const Vector &_Angles, const int &_Sequence);

    /** 
        * Create a Rotation from an euler angle sequence.
        * @param _Angle1 first angles in Euler angle set. [rad]
        * @param _Angle2 second angles in Euler angle set. [rad]
        * @param _Angle3 third angles in Euler angle set. [rad]
        * @param _Sequence Euler angle rotation sequence. (ie 123, 213, 313, 321, etc).
        */
    Rotation(const double &_Angle1, const double &_Angle2, const double &_Angle3, const int &_Sequence);


    /** 
        * Create a Rotation from a given euler axis and angle.
        * @param Axis 3x1 Euler Axis
        * @param Angle Angle rotation about axis [rad].
        */
    Rotation(const Vector &_Axis, const double &_Angle);

    /** 
        * Create a Rotation from a given set of Modified Rodriguez Parameters.
        * @param _MRP 3x1 MRP vector to be represented.
        */
    Rotation(const ModifiedRodriguezParameters &_MRP);

    /** 
        * Create a Rotation from a given quaternion.
        * @param _quat 4x1 quaternion to be represented.
        */
    Rotation(const Quaternion &_quat);

    /** 
        * Default Destructor.
        */    
    ~Rotation();

    // end of RotationConstructors

    // RotationMutators
    /** 
        * Set the Rotation from a converted DCM.
        * @param _inMatrix 3x3 matrix of Direction Cosine Matrix (DCM) values.
        */
    void Set(const Matrix &_inMatrix);

    /** 
        * Set the Rotation from a converted DCM.
        * @param _DCM 3x3 matrix of Direction Cosine Matrix (DCM) values.
        */
    void Set(const DirectionCosineMatrix &_DCM);

    /** 
        * Set the Rotation from an euler angle sequence.
        * @param _Angles 3x1 matrix of euler angles.
        * @param _Sequence Euler angle rotation sequence. (ie 123, 213, 313, 321, etc).
        */
    void Set(const Vector &_Angles, const int &_Sequence);

    /** 
        * Create a Rotation from an euler angle sequence.
        * @param _Angle1 first angles in Euler angle set. [rad]
        * @param _Angle2 second angles in Euler angle set. [rad]
        * @param _Angle3 third angles in Euler angle set. [rad]
        * @param _Sequence Euler angle rotation sequence. (ie 123, 213, 313, 321, etc).
        */
    void Set(const double &_Angle1, const double &_Angle2, const double &_Angle3, const int &_Sequence);

    /** 
        * Set the Rotation from a converted Euler Axis and Angle set.
        * @param _Axis 3x1 Euler Axis.
        * @param _Angle Angle rotation about axis [rad].
        */
    void Set(const Vector &_Axis, const double &_Angle);

    /** 
        * Set the Rotation from a converted vector of MRP.
        * @param _MRP 3x1 vector of Modified Rodriguez Parameters to set the Rotation.
        */
    void Set(const ModifiedRodriguezParameters &_MRP);

    /** 
        * Set the Rotation from a converted quaternion.
        * @param _quat 4x1 quaternion to set the Rotation.
        */
    void Set(const Quaternion &_quat);

    // end of RotationMutators

    // RotationInspectors
    /** 
        * Return the Direction Cosine Matrix (DCM) form of the attitude transformation.
        * @return 3x3 Direction Cosine Matrix (DCM).
        */
    DirectionCosineMatrix GetDCM() const;

    /** 
        * Return the Euler angles from the rotation representation.
        * @param _Sequence Euler angle rotation sequence. (ie 123, 213, 313, 321, etc).
        * @return _Angles 3x1 matrix of euler angles.
        */
    Vector GetEulerAngles(const int& _Sequence);

    /** 
        * Return the Euler Axis and Angle form of the attitude transformation.
        * @param _EulerAxis 3x1 Euler Axis to be returned.
        * @param _EulerAngle Euler angle of rotation [rad].
        */
    void GetEulerAxisAngle(Vector &_EulerAxis, double &_EulerAngle) const;

    /** 
        * Return the Modified Rodriguez Parameters vector form of the attitude transformation.
        * @return 3x1 MRP vector.
        */
    ModifiedRodriguezParameters GetMRP() const;


    /** 
        * Return the quaternion form of the attitude transformation.
        * @return 4x1 quaternion.
        */
    Quaternion GetQuaternion() const;

    // end of RotationInspectors

    // RotationOperators
    /** 
        * Multiply the rotation matrices together.
        * @return 3x3 Direction Cosine Matrix (DCM).
        */
    Rotation Rotation::operator* (const Rotation& _rot2) const;

    /** 
        * Take the inverse of the rotation matrix.
        * @return 3x3 Direction Cosine Matrix (DCM).
        */
    Rotation Rotation::operator~ () const;

    /** 
        * Determine the successive rotation from the summation of two rotations.
        * @param _rot2 Rotation to be summed with.
        */
    Rotation Rotation::operator+ (const Rotation& _rot2) const;

    /** 
        * Determine the relative rotation from the difference of two rotations.
        * @param _rot2 Rotation to be differenced with.
        */
    Rotation Rotation::operator- (const Rotation& _rot2) const;
    // end of RotationOperators

private:
        /*! internal representation of the attitude transformation.*/
        Quaternion m_quaternion;

};
/** @} */ // end of Rotation
/** @} */ // end of AttitudeRepresentation
#endif 
